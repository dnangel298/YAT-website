import "./App.css";
import Home from "./Layout/Home";

export default function App() {
  return <Home />;
}
